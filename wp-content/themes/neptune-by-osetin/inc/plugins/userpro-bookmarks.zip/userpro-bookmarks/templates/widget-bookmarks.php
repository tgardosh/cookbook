<div class="updb-widget-style">
	<div class="updb-basic-info"><?php _e( 'Public Bookmark', 'userpro-dashboard' );?></div>
<div class="updb-view-profile-details"><br>

<?php echo do_shortcode('[userpro_publicbookmark/]');

?>

</div>
</div>
