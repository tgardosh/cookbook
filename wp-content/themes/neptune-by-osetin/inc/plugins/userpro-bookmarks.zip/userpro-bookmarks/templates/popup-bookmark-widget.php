<div class="userpro-bookmark-overlay-content">

	<a href="#" onclick="userpro_bookmark_close_overlay()" class="userpro-bookmark-close"><?php _e('Close','userpro'); ?></a>

	<div class="userpro-bookmark-new">

		<div class="userpro-bookmark-user">
			
			
			<div class="userpro-bookmark-user-info">
				<div class="userpro-bookmark-user-name">
					<?php global $userpro_fav;
		echo $userpro_fav->bookmarkpouup($post_id)?>
			</div>
			
		<div class="userpro-clear"></div>
		</div>
		
		
	</div>

</div>
